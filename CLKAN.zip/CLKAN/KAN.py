from KANlinear import *

"""
KAN (Kolmogorov-Arnold Network) class

A neural network architecture using learnable spline-based activation functions
instead of fixed activation functions. Implements the Kolmogorov-Arnold representation
theorem for multivariate function approximation.

The source of KAN's code refers to the article:
Liu Z, Wang Y, Vaidya S, Ruehle F, Halverson J, Soljačić M, et al. 
KAN: Kolmogorov-Arnold Networks. arXiv preprint arXiv 2024; 2404:19756. 
https://doi.org/10.48550/arXiv.2404.19756.

Attributes:
-----------
    grid_size: int
        Number of grid intervals for spline functions (default=17)
    spline_order: int
        Order of B-spline polynomials (degree = spline_order - 1) (default=3)
    scale_noise: float
        Magnitude of noise added during spline initialization (default=0.1)
    scale_base: float
        Scaling factor for the residual base function (default=1.0)
    scale_spline: float
        Scaling factor for spline functions (default=1.0)
    base_activation: torch.nn.Module
        Activation function for residual term (default=torch.nn.SiLU)
    grid_eps: float
        Grid update interpolation factor: 
        0.0 = percentile-based, 1.0 = uniform grid (default=0.02)
    grid_range: list[float, float]
        Initial grid range for spline functions (default=[-1, 1])
    layers: torch.nn.ModuleList
        Container for KANLinear layers with dimensions:
        layers_hidden[0] → layers_hidden[1] → ... → layers_hidden[-1]

Initialization Parameters:
--------------------------
    layers_hidden: list[int]
        Network architecture specification (e.g., [32, 32, 1] for 3 layers)

Forward Pass:
-------------
    Input: 
        x: torch.Tensor - input tensor of shape [batch_size, input_dim]
        update_grid: bool - whether to update spline grids (default=False)
    Output: 
        torch.Tensor - output tensor of shape [batch_size, output_dim]

Processing Flow:
    1. For each KANLinear layer in self.layers:
        if update_grid=True → update spline grids using input distribution
        x = layer(x)
    2. Returns final transformed tensor

Additional Methods:
-------------------
    regularization_loss(regularize_activation=1.0, regularize_entropy=1.0)
        Computes regularization loss for network optimization
        Returns sum of regularization terms from all layers
        - regularize_activation: weight for L1 regularization of activation magnitudes
        - regularize_entropy: weight for entropy regularization of spline weights
"""

class KAN(torch.nn.Module):
    def __init__(
        self,
        layers_hidden,
        grid_size=17,
        spline_order=3,
        scale_noise=0.1,
        scale_base=1.0,
        scale_spline=1.0,
        base_activation=torch.nn.SiLU,
        grid_eps=0.02,
        grid_range=[-1, 1],
    ):
        super(KAN, self).__init__()
        self.grid_size = grid_size
        self.spline_order = spline_order
        self.layers = torch.nn.ModuleList()
        for in_features, out_features in zip(layers_hidden, layers_hidden[1:]):
            self.layers.append(
                KANLinear(
                    in_features,
                    out_features,
                    grid_size=grid_size,
                    spline_order=spline_order,
                    scale_noise=scale_noise,
                    scale_base=scale_base,
                    scale_spline=scale_spline,
                    base_activation=base_activation,
                    grid_eps=grid_eps,
                    grid_range=grid_range,
                )
            )

    def forward(self, x: torch.Tensor, update_grid=False):
        for layer in self.layers:
            if update_grid:
                layer.update_grid(x)
            x = layer(x)
        return x

    def regularization_loss(self, regularize_activation=1.0, regularize_entropy=1.0):
        return sum(
            layer.regularization_loss(regularize_activation, regularize_entropy)
            for layer in self.layers
        )
