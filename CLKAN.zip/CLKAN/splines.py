import torch


def b_splines(
        x: torch.Tensor,
        grid: torch.Tensor,
        spline_order: int,
        in_features: int,
        grid_size: int
):
    """
    Compute the B-spline bases for the given input tensor.

    Args:
        x (torch.Tensor): Input tensor of shape (batch_size, in_features).
        grid (torch.Tensor): Precomputed grid tensor.
        spline_order (int): Order of the spline.
        in_features (int): Number of input features.
        grid_size (int): Size of the grid.

    Returns:
        torch.Tensor: B-spline bases tensor of shape (batch_size, in_features, grid_size + spline_order).
    """
    assert x.dim() == 2 and x.size(1) == in_features

    x = x.unsqueeze(-1)
    bases = ((x >= grid[:, :-1]) & (x < grid[:, 1:])).to(x.dtype)

    for k in range(1, spline_order + 1):
        bases = (
                        (x - grid[:, : -(k + 1)])
                        / (grid[:, k:-1] - grid[:, : -(k + 1)] + 1e-8)
                        * bases[:, :, :-1]
                ) + (
                        (grid[:, k + 1:] - x)
                        / (grid[:, k + 1:] - grid[:, 1:(-k)] + 1e-8)
                        * bases[:, :, 1:]
                )

    assert bases.size() == (x.size(0), in_features, grid_size + spline_order)
    return bases.contiguous()