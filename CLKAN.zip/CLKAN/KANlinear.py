import torch
import torch.nn.functional as F
import math
from splines import b_splines

"""
KANLinear (Kolmogorov-Arnold Network Linear Layer) class

Implements the core computational layer of KAN networks, replacing traditional linear 
transformations with learnable spline-based functions. Combines a linear base function 
with adaptive spline activations for enhanced function approximation.

Attributes:
-----------
    in_features: int
        Number of input features/dimensions
    out_features: int
        Number of output features/dimensions
    grid_size: int
        Number of grid intervals for spline functions (default=17)
    spline_order: int
        Order of B-spline polynomials (degree = spline_order - 1) (default=3)
    grid: torch.Tensor (buffer)
        Grid points defining spline basis functions (shape: [in_features, grid_size + 2*spline_order + 1])
    base_weight: torch.nn.Parameter
        Weight matrix for residual base function (shape: [out_features, in_features])
    spline_weight: torch.nn.Parameter
        Coefficient tensor for spline basis functions (shape: [out_features, in_features, grid_size + spline_order])
    spline_scaler: torch.nn.Parameter (optional)
        Per-feature scaling factors for spline functions when enable_standalone_scale_spline=True
    scale_noise: float
        Magnitude of noise during spline initialization (default=0.1)
    scale_base: float
        Scaling factor for base function output (default=1.0)
    scale_spline: float
        Global scaling factor for spline functions (default=1.0)
    base_activation: torch.nn.Module
        Activation function for residual term (default=SiLU)
    grid_eps: float
        Grid update interpolation factor (0.0=percentile-based, 1.0=uniform) (default=0.02)

Initialization Parameters:
--------------------------
    enable_standalone_scale_spline: bool
        Whether to use separate scaling parameters for each spline function (default=True)
    grid_range: list[float, float]
        Initial domain for spline operations (default=[-1,1])

Key Methods:
------------
    reset_parameters():
        Initializes weights using Kaiming uniform distribution for base weights,
        and spline weights via curve fitting to noisy initialization data.

    curve2coeff(x: Tensor, y: Tensor) -> Tensor:
        Computes B-spline coefficients using least-squares fitting.
        Inputs:
            x: [batch_size, in_features]
            y: [batch_size, in_features, out_features]
        Output: [out_features, in_features, grid_size + spline_order]

    b_splines(x: Tensor) -> Tensor:
        Computes B-spline basis values for input tensor.
        Output: [batch_size, in_features, grid_size + spline_order]

    forward(x: Tensor) -> Tensor:
        Computes layer output: base_activation(x) @ base_weight^T + spline_term
        Spline term: b_splines(x) * scaled_spline_weight

    update_grid(x: Tensor, margin=0.01):
        Adapts grid points to input data distribution using:
          grid = grid_eps*grid_uniform + (1-grid_eps)*grid_adaptive
        Then recomputes spline coefficients via curve fitting.

    regularization_loss() -> Tensor:
        Computes compound regularization loss:
          L1 activation loss + Entropy regularization
"""


class KANLinear(torch.nn.Module):
    def __init__(
            self,
            in_features,
            out_features,
            grid_size=17,
            spline_order=3,
            scale_noise=0.1,
            scale_base=1.0,
            scale_spline=1.0,
            enable_standalone_scale_spline=True,
            base_activation=torch.nn.SiLU,
            grid_eps=0.02,
            grid_range=[-1, 1],
    ):
        super(KANLinear, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.grid_size = grid_size
        self.spline_order = spline_order

        h = (grid_range[1] - grid_range[0]) / grid_size
        grid = (
            (
                    torch.arange(-spline_order, grid_size + spline_order + 1) * h
                    + grid_range[0]
            )
            .expand(in_features, -1)
            .contiguous()
        )
        self.register_buffer("grid", grid)

        self.base_weight = torch.nn.Parameter(torch.Tensor(out_features, in_features))
        self.spline_weight = torch.nn.Parameter(
            torch.Tensor(out_features, in_features, grid_size + spline_order)
        )
        if enable_standalone_scale_spline:
            self.spline_scaler = torch.nn.Parameter(
                torch.Tensor(out_features, in_features)
            )

        self.scale_noise = scale_noise
        self.scale_base = scale_base
        self.scale_spline = scale_spline
        self.enable_standalone_scale_spline = enable_standalone_scale_spline
        self.base_activation = base_activation()
        self.grid_eps = grid_eps

        self.reset_parameters()

    def reset_parameters(self):
        torch.nn.init.kaiming_uniform_(self.base_weight, a=math.sqrt(5) * self.scale_base)
        with torch.no_grad():
            noise = (
                    (
                            torch.rand(self.grid_size + 1, self.in_features, self.out_features)
                            - 1 / 2
                    )
                    * self.scale_noise
                    / self.grid_size
            )
            self.spline_weight.data.copy_(
                (self.scale_spline if not self.enable_standalone_scale_spline else 1.0)
                * self.curve2coeff(
                    self.grid.T[self.spline_order: -self.spline_order],
                    noise,
                )
            )
            if self.enable_standalone_scale_spline:
                torch.nn.init.kaiming_uniform_(self.spline_scaler, a=math.sqrt(5) * self.scale_spline)

    def curve2coeff(self, x: torch.Tensor, y: torch.Tensor):
        assert x.dim() == 2 and x.size(1) == self.in_features
        assert y.size() == (x.size(0), self.in_features, self.out_features)

        A = b_splines(
            x,
            self.grid,
            self.spline_order,
            self.in_features,
            self.grid_size
        ).transpose(0, 1)

        B = y.transpose(0, 1)
        solution = torch.linalg.lstsq(
            A, B
        ).solution
        result = solution.permute(
            2, 0, 1
        )

        assert result.size() == (
            self.out_features,
            self.in_features,
            self.grid_size + self.spline_order,
        )
        return result.contiguous()

    @property
    def scaled_spline_weight(self):
        return self.spline_weight * (
            self.spline_scaler.unsqueeze(-1)
            if self.enable_standalone_scale_spline
            else 1.0
        )

    def forward(self, x: torch.Tensor):
        assert x.size(-1) == self.in_features
        original_shape = x.shape
        x = x.view(-1, self.in_features)

        base_output = F.linear(self.base_activation(x), self.base_weight)
        spline_bases = b_splines(
            x,
            self.grid,
            self.spline_order,
            self.in_features,
            self.grid_size
        )

        spline_output = F.linear(
            spline_bases.view(x.size(0), -1),
            self.scaled_spline_weight.view(self.out_features, -1),
        )
        output = base_output + spline_output

        output = output.view(*original_shape[:-1], self.out_features)
        return output

    @torch.no_grad()
    def update_grid(self, x: torch.Tensor, margin=0.01):
        assert x.dim() == 2 and x.size(1) == self.in_features

        splines = b_splines(
            x,
            self.grid,
            self.spline_order,
            self.in_features,
            self.grid_size
        )
        batch = x.size(0)

        orig_coeff = self.scaled_spline_weight
        orig_coeff = orig_coeff.permute(1, 2, 0)
        unreduced_spline_output = torch.bmm(splines, orig_coeff)
        unreduced_spline_output = unreduced_spline_output.permute(
            1, 0, 2
        )

        x_sorted = torch.sort(x, dim=0)[0]
        grid_adaptive = x_sorted[
            torch.linspace(
                0, batch - 1, self.grid_size + 1, dtype=torch.int64, device=x.device
            )
        ]

        uniform_step = (x_sorted[-1] - x_sorted[0] + 2 * margin) / self.grid_size
        grid_uniform = (
                torch.arange(
                    self.grid_size + 1, dtype=torch.float32, device=x.device
                ).unsqueeze(1)
                * uniform_step
                + x_sorted[0]
                - margin
        )

        grid = self.grid_eps * grid_uniform + (1 - self.grid_eps) * grid_adaptive
        grid = torch.concatenate(
            [
                grid[:1]
                - uniform_step
                * torch.arange(self.spline_order, 0, -1, device=x.device).unsqueeze(1),
                grid,
                grid[-1:]
                + uniform_step
                * torch.arange(1, self.spline_order + 1, device=x.device).unsqueeze(1),
            ],
            dim=0,
        )

        self.grid.copy_(grid.T)
        self.spline_weight.data.copy_(self.curve2coeff(x, unreduced_spline_output))

    def regularization_loss(self, regularize_activation=1.0, regularize_entropy=1.0):
        l1_fake = self.spline_weight.abs().mean(-1)
        regularization_loss_activation = l1_fake.sum()
        p = l1_fake / regularization_loss_activation
        regularization_loss_entropy = -torch.sum(p * p.log())
        return (
                regularize_activation * regularization_loss_activation
                + regularize_entropy * regularization_loss_entropy
        )


