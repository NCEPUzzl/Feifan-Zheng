import warnings

warnings.filterwarnings("ignore", category=UserWarning)
import pandas as pd
from sklearn.metrics import mean_absolute_error
from torch.utils.data import DataLoader, Dataset
from torch import nn
import numpy as np
from KAN import *
from sklearn.preprocessing import MinMaxScaler
from tqdm import tqdm
import torch
import time
import os


"""
CNN_LSTM_KAN_Model class

A hybrid neural network architecture combining Convolutional Neural Networks (CNN), 
Long Short-Term Memory (LSTM) networks, and Kolmogorov-Arnold Networks (KAN) for 
multivariate time series forecasting.

Attributes:
-----------
    num_inputs: int
        Number of input features/dimensions (corresponds to number of time series variables)
    sequence_length: int
        Length of input time sequence (number of historical time steps)
    kernel_size: int
        Size of convolutional kernel (temporal window for feature extraction)
    dropout: float
        Dropout probability for regularization (range: 0.0-1.0)
    conv1: torch.nn.Conv1d
        1D convolutional layer with parameters:
            in_channels = num_inputs
            out_channels = 64
            kernel_size = kernel_size
            padding = (kernel_size - 1) // 2 (preserves sequence length)
    relu: torch.nn.ReLU
        Rectified Linear Unit activation function
    dropout_layer: torch.nn.Dropout
        Dropout layer with probability = dropout
    pool: torch.nn.MaxPool1d
        Max pooling layer with parameters:
            kernel_size = 2
            stride = 2 (halves sequence length)
    lstm: torch.nn.LSTM
        LSTM layer with parameters:
            input_size = 64 (matches CNN output channels)
            hidden_size = 32
            num_layers = 1
            batch_first = True (input format: [batch, seq, features])
    kan: KAN
        Kolmogorov-Arnold Network with fixed architecture:
            layers = [32, 32, 1] (input:32, hidden:32, output:1)

Forward Pass:
-------------
    Input shape: [batch_size, num_inputs, sequence_length]
    Output shape: [batch_size, 1]

Processing Stages:
    1. CNN Feature Extraction:
        - Temporal pattern extraction via 1D convolution
        - ReLU activation
        - Dropout regularization
        - Sequence downsampling via max pooling
    2. LSTM Temporal Modeling:
        - Processes downsampled sequences
        - Outputs final hidden state (captures temporal dependencies)
    3. KAN Nonlinear Regression:
        - Maps LSTM output (32-dim) to prediction (1-dim)
        - Uses learnable spline-based activation functions
"""


class CNN_LSTM_KAN_Model(nn.Module):
    def __init__(self, num_inputs, sequence_length, kernel_size, dropout):
        super(CNN_LSTM_KAN_Model, self).__init__()
        self.num_inputs = num_inputs
        self.sequence_length = sequence_length
        self.kernel_size = kernel_size
        self.dropout = dropout

        # CNN
        self.conv1 = nn.Conv1d(
            in_channels=num_inputs,
            out_channels=64,
            kernel_size=kernel_size,
            padding=(kernel_size - 1) // 2
        )
        self.relu = nn.ReLU()
        self.dropout_layer = nn.Dropout(dropout)
        self.pool = nn.MaxPool1d(kernel_size=2, stride=2)

        # LSTM
        self.lstm = nn.LSTM(
            input_size=64,
            hidden_size=32,
            num_layers=1,
            batch_first=True
        )

        # KAN
        self.kan = KAN([32, 32, 1])

    def forward(self, x):
        x = self.conv1(x)
        x = self.relu(x)
        x = self.dropout_layer(x)
        x = self.pool(x)
        x = x.permute(0, 2, 1)

        lstm_out, _ = self.lstm(x)
        lstm_last = lstm_out[:, -1, :]

        output = self.kan(lstm_last)
        return output


# ================== Data loading and processing ==================
class MyDataset(Dataset):
    def __init__(self, x, y):
        self.x = torch.from_numpy(x).float()
        self.y = torch.from_numpy(y).float()

    def __getitem__(self, index):
        return self.x[index], self.y[index]

    def __len__(self):
        return len(self.x)


def load_data(file_path, sequence_length):
    data = pd.read_csv(file_path)
    scaler = MinMaxScaler()
    scaled_data = scaler.fit_transform(data)
    x, y = [], []

    for i in range(scaled_data.shape[0] - sequence_length):
        x.append(scaled_data[i:i + sequence_length, :])
        y.append(scaled_data[i + sequence_length, -1])
    x = np.array(x, dtype=np.float32)
    y = np.array(y, dtype=np.float32).reshape(-1, 1)
    x = np.transpose(x, (0, 2, 1))
    return x, y, scaler


def train_model(model, train_loader, num_epochs, device):
    model.to(device)
    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

    for epoch in range(num_epochs):
        model.train()
        epoch_loss = 0
        for x_batch, y_batch in tqdm(train_loader, desc=f'Epoch {epoch + 1}/{num_epochs}'):
            x_batch = x_batch.to(device)
            y_batch = y_batch.to(device)
            optimizer.zero_grad()
            predictions = model(x_batch)
            loss = criterion(predictions, y_batch)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()
    return model


def evaluate_model(model, test_loader, scaler, device):
    model.eval()
    predictions, actuals = [], []
    with torch.no_grad():
        for x_batch, y_batch in test_loader:
            x_batch = x_batch.to(device)
            preds = model(x_batch).cpu().numpy()
            actuals.append(y_batch.numpy())
            predictions.append(preds)

    predictions = np.vstack(predictions)
    actuals = np.vstack(actuals)

    predictions = predictions * (scaler.data_max_[-1] - scaler.data_min_[-1]) + scaler.data_min_[-1]
    actuals = actuals * (scaler.data_max_[-1] - scaler.data_min_[-1]) + scaler.data_min_[-1]

    mae = mean_absolute_error(actuals, predictions)
    return predictions, actuals, mae


if __name__ == "__main__":
    sequence_length = 32
    batch_size = 32
    num_inputs = 4
    num_epochs = 100
    kernel_size = 5
    dropout = 0.2754

    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    train_x, train_y, scaler_train = load_data("...csv", sequence_length)
    test_x, test_y, scaler_test = load_data("...csv", sequence_length)

    train_dataset = MyDataset(train_x, train_y)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_dataset = MyDataset(test_x, test_y)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    model = CNN_LSTM_KAN_Model(
        num_inputs=num_inputs,
        sequence_length=sequence_length,
        kernel_size=kernel_size,
        dropout=dropout
    ).to(device)

    total_params = sum(p.numel() for p in model.parameters())
    print(f"Model Parameters: {total_params}")

    model.eval()
    dummy_input = torch.randn(1, num_inputs, sequence_length).to(device)

    start_time = time.time()
    model = train_model(model, train_loader, num_epochs, device)
    end_time = time.time()
    training_time = end_time - start_time
    print(f"Training completed in {training_time:.2f} seconds")

    test_sample = torch.randn(1, num_inputs, sequence_length).to(device)
    start_infer = time.time()
    with torch.no_grad():
        for _ in range(100):
            _ = model(test_sample)
    infer_time = (time.time() - start_infer) / 100
    print(f"Inference time per sample: {infer_time * 1000:.2f} ms")

    predictions, actuals, mae = evaluate_model(model, test_loader, scaler_test, device)
    print(f"Test MAE: {mae:.6f}")

    os.makedirs('results', exist_ok=True)

    results = pd.DataFrame({
        'actual_value': actuals.flatten(),
        'prediction_value': predictions.flatten(),
        'Absolute error': np.abs(actuals.flatten() - predictions.flatten())
    })
    results.to_csv('results/CLKAN_predictions.csv', index=False)

